#include <stdio.h>
#include "calc.h"

int main()
{
	char string[100];
	double a;
	int stat;
	//string _must_ end with '='!
	strcpy(string,"-5*(-2+1)/(0.1*5)=");
	char *p = string;
	//if all is OK, 'a' get a result of calculation and 'stat'==0
	//if something is wrong 'stat'==-1 and 'a' is undefined
	a = Calc(&p,&stat);
	if(stat == 0){
		printf("%s%f\n",string,a);
	}else{
		printf("Test failed\n");
	}
	getchar();
	return 0;
}